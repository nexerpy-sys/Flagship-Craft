# Execution and Verification

Load this for long multi-step agentic work, for a bug that survived a first fix, and whenever you are about to report a substantial task as done. It is self-contained.

Purpose: stop the two opposite failures of agentic work. One is stopping at the first plausible checkpoint. The other is claiming more than was observed.

## The loop

Run, observe, critique, fix, retest. Each word is a distinct act, and each produces something a reviewer could see.

1. Run. Execute the real thing: the program, the test suite, the build, the request, the rendered screen. Use the same entry point a user would use, when possible.
2. Observe. Read the actual output: exit codes, the test summary, response bodies, logs, the screenshot. Read all of it, not only the last line. Do not infer the output from the code.
3. Critique. Compare what you observed against the frame: outcome, invariants, chosen failure mode. Name the single most important gap.
4. Fix. Change one thing aimed at that gap.
5. Retest. Rerun the check that exposed the gap, and the nearest check that was passing before.

One gap per cycle. Fixing several things at once makes it impossible to know which change did what.

## Building in observable steps

- Get one thin path working end to end before adding breadth. Then every later step can be run.
- After each meaningful change, run something. The longer you go without executing, the more of your state is prediction.
- Keep a short working list of what is done, what is in progress and what is unverified. Update it as you go. On long tasks, this is what keeps the final report honest.
- Prefer checks that are cheap to repeat: a single command, a script, a saved request. You will rerun them many times.

## The evidence ladder

Label every claim by the strongest evidence you actually have.

| Level | What you did | What you may say |
| --- | --- | --- |
| A - Observed behavior | Ran it and read the real output, or inspected a real capture | "Verified: ran X, observed Y" |
| B - Checked source of truth | Read current official docs, installed source or types, or the real schema, for the matching version | "Checked against the docs or source for version N" |
| C - Static tool passed | Compiler, type checker or linter passed | "Compiles" or "type-checks". Not "works" |
| D - Read the code | Reasoned about the code by reading it | "Not verified. By inspection, I expect ..." |
| E - Assumed | Did not look | "Assumption: ..." |

Rules:

- Only level A supports the words "verified", "tested", "works" and "confirmed" about behavior.
- Level C is real, but narrow. It says nothing about runtime behavior, layout or correctness of logic.
- Level D is a hypothesis however confident you feel. Confidence from reading code is the main source of false "done" reports.
- A check that ran against a mock verifies the code's interaction with the mock. Say that it was mocked.
- A check performed before your last edit is stale for anything that edit could affect. Rerun it, or downgrade the claim.
- Output you did not fully read is not observed. If a log was truncated, say so.

## What to check, by kind of work

Choose the checks that could actually fail. Skip the ones that cannot.

- Logic and services: run the tests. Call the real endpoint with a valid input, an invalid input and a repeated input. Provoke the chosen failure mode. Read the logs for unexpected errors and warnings.
- Data changes: inspect the stored state after the operation, not only the response. Run migrations forward on realistic data. State whether rollback was tried.
- User interface: load it. Exercise the main flow by real interaction. Capture the relevant viewport sizes. Look at the empty, error and long-content states. Check the browser or device console for errors.
- Motion: observe it running. Interrupt it, repeat it, and try it with reduced motion.
- Command-line tools: run interactively and piped. Check exit codes. Interrupt it mid-run.
- Integrations: make one real call when credentials and a sandbox exist. Otherwise state that it is mocked or unexercised.
- Performance claims: measure before and after with the same method. No measurement, no claim.
- Documentation or facts you cite: open the source. Do not cite from memory as if checked.

## Debugging discipline

When a check fails:

1. Read the whole error, including the first error and not only the last one.
2. Reproduce it with the smallest input that still fails.
3. State one hypothesis for the cause, and what observation would confirm or refute it.
4. Make that observation: a log line, a breakpoint, a direct query, a minimal script. Do this before changing the code.
5. Fix the cause. Rerun the reproduction. Then rerun the neighbors.

Stop-and-rethink triggers:

- The same check failed twice after two different fixes. Your model of the problem is wrong. Go back to step 3. Do not attempt a third variation.
- You are about to change the test so that it passes. First decide, from the requirements, whether the test or the code is wrong.
- You are about to add a retry, a sleep, a broad exception handler or a special case to make a symptom go away. That hides the cause. Find it.
- The fix works, and you cannot explain why. It is not fixed.

Never disable, skip or weaken a check to get to green without saying so explicitly in the report.

## Stopping rule

Stop too early and you ship a guess. Stop too late and you waste the user's time and money. Stop when all of these hold:

- The outcome in the frame is demonstrated by a level A check, or the reason it cannot be is stated.
- Each invariant has a level A check, or an entry under "not verified".
- At least one failure was provoked on purpose and handled correctly.
- For visual work, rendered output was inspected at the relevant sizes, and the weakest visible decision was revised at least once. Or the absence of rendering tools is stated.
- Nothing has been edited since the last relevant check ran.
- A final pass found no remaining issue that you would fix if asked "is this really done?"

Then stop. Do not add unrequested features, refactors or extra polish after the rule is met. List ideas under next steps instead.

When you are blocked by a missing credential, a missing tool or an environment limit, do not loop. Finish everything that does not depend on the blocker. State the blocker precisely. State what remains unverified because of it.

## Report format

Use this structure at the end of every bounded or substantial task. Keep it short. One line per item.

```text
Result
One or two sentences: what now exists and what it does.

Verified (checks I ran and observed)

- <what I ran> -> <what I observed>

Not verified (and why)

- <what was not checked> - <reason: no tool, no credentials, out of scope, not run>

Assumptions and risks

- <decision made on the user's behalf, or the most likely way this breaks>

Next steps (optional)

- <only items the user would plausibly want>
```

Rules for the report:

- Every line under "Verified" names a concrete action and a concrete observation. "Reviewed the code" does not belong there.
- "Not verified" is never empty by omission. If there is nothing to list, write "none", and be sure that is true.
- Do not soften the second group with phrases like "should work" or "expected to pass". State what was not done.
- Do not summarize the two groups into one reassuring sentence. The separation is the point.
- If something is known to be broken or mocked, say so first, not last.
- Report failures you fixed along the way only when they change what the user should trust.

## Default Output vs. Flagship Output

Task: "Fix the bug where the dashboard total is sometimes wrong."

Default output:

- Reads the aggregation code, spots a plausible off-by-one in a date range, changes it.
- Reports: "Fixed the date range bug. The totals should now be correct."
- Evidence level D, presented as a fix.

Flagship output:

- Reproduces a wrong total first, using a record created near midnight, and writes it down as a failing test. Observes the failure.
- Finds by a direct query that the mismatch is a timezone boundary: records are stored in UTC and grouped by local date. The off-by-one that looked plausible was not the cause.
- Fixes the grouping. Reruns the failing test and sees it pass. Reruns the whole suite.
- Reports: "Verified: reproduced the wrong total with a record at 23:30 local time. After the fix that test passes, and all 42 tests pass. Not verified: daylight-saving transition days - no test data for them. Risk: any saved report computed before this fix still holds the old totals."

## Self-check before sending the report

- For each line under "Verified": did I execute something and read its output in this session, after my last relevant edit?
- Is there any claim in the summary sentence that belongs under "Not verified"?
- Did I provoke a failure, or only run the path I built?
- Did I weaken, skip or mock any check, and does the report say so?
- Am I stopping because the stopping rule is met, or because the result looks plausible?
