# Motion and Interaction

Load this when something the user sees changes state or moves: transitions, gestures, drag, loading feedback, animation, games or interactive visuals. It is self-contained. The principles apply on any platform. Use the platform's own animation system and units. Do not assume CSS.

## The standard

Motion is information. A flagship interface uses movement to explain what happened and to confirm input, and it feels like one consistent physical world. Cosmetic motion is added after the fact, is the same everywhere, and delays the user.

Three observable tests:

- Purpose test: for each animation, complete the sentence "this tells the user that ...". If you cannot, remove it.
- Interruption test: trigger an animation and reverse it halfway. The element should turn around from where it is, without jumping, and the new input should take effect at once.
- Repetition test: perform the action twenty times quickly. If the motion becomes an obstacle, it is too long or should not exist for a frequent action.

## Step 1 - Decide what earns motion

Valid purposes, and what each one implies:

| Purpose | What the motion must show | Typical form |
| --- | --- | --- |
| Acknowledge input | "I received that", fast enough to feel caused by the touch | Immediate state change on press, small scale or tone shift |
| Show origin and destination | Where a thing came from or went | Element moves or grows from its trigger. Exits return toward where they will be found again |
| Show what changed | Which part of the view is different now | Only the changed elements move. Everything else stays still |
| Show relationship | That two things are the same object or parent and child | Shared element continuity between two views |
| Show system status | That work is in progress, and roughly how much | Progress indication, skeletons that match the final layout |
| Direct attention | Something needs the user now | One brief movement, used rarely |

Things that should usually not animate: high-frequency actions such as typing, keyboard navigation and rapid toggles. Also content the user is trying to read, and anything during initial load that delays first use.

## Step 2 - Timing

These ranges are starting points drawn from platform motion guidelines and common practice. They are not laws. Adjust by looking at the result.

| Kind of change | Starting range |
| --- | --- |
| Direct feedback to a press, hover or toggle | 80 to 150 ms |
| Small element entering, leaving or changing: tooltip, menu, chip | 150 to 250 ms |
| Medium surface: dialog, sheet, panel, card expansion | 250 to 400 ms |
| Large or full-view transition | 300 to 500 ms |

Rules that explain the ranges:

- A response within roughly 100 ms of input feels instantaneous. Feedback to a direct touch must start in that window, even if the full transition takes longer.
- Duration scales with distance and size. A thing crossing the whole screen takes longer than a thing moving a few pixels. Giving both the same duration makes one feel sluggish or the other abrupt.
- Exits are shorter than entrances. The user has already decided, and the leaving element is no longer the subject. Around two thirds to three quarters of the entrance duration is a reasonable start.
- Above about half a second, an interface transition starts to feel like waiting. Longer durations belong to storytelling moments the user chose to watch, not to navigation.
- If an operation's real duration is unknown, do not hide it behind a fixed-length animation. Show status, and resolve as soon as the work completes.

## Step 3 - Easing and physics

Choose the curve from what the object is doing.

- Entering or responding to the user: decelerate. Start fast, settle gently. The fast start reads as responsive.
- Leaving for good: accelerate. Start gently, leave fast.
- Moving between two on-screen positions: accelerate, then decelerate.
- Linear: only for continuous, non-spatial change, such as a progress fill, a rotation loop or a color crossfade. Linear movement of an object looks mechanical because real objects do not start and stop instantly.

Springs:

- Prefer a spring over a fixed curve for anything driven by a gesture, or anything that can be interrupted. A spring carries the current velocity into the new motion, so a reversal or a release looks continuous. A fixed curve restarts from zero velocity and visibly hitches.
- Describe a spring by how it settles. Critically damped or close to it, with no overshoot, suits most interface surfaces. Slight underdamping with a small single overshoot suits playful or physical elements. Visible oscillation rarely suits anything that the user must act on next.
- Hand off velocity: when a drag ends, the animation begins at the finger's release velocity. A flick should travel farther than a slow release.
- Parameter names differ by platform: stiffness and damping, response and damping ratio, tension and friction. Tune by observation. No parameter set is universal.

One world:

- Define a small set of named motion tokens, usually three or four durations and two or three curves or springs, and use only those. This makes the interface feel like it has one physics.
- Similar things move the same way. Different things do not. A tooltip and a full-screen sheet sharing one duration is a defect.

## Step 4 - Choreography

When several things change at once, order them so the eye knows where to go.

- One lead: the most important element moves first or most. Supporting elements follow, with less distance and less emphasis.
- Stagger lists by a small per-item offset, around 20 to 50 ms, and cap the total so the last item is not noticeably late. Past roughly six to eight items, animate the group as one.
- Things that are related move together and in the same direction. Unrelated things do not move at all.
- Outgoing content leaves before or while incoming content arrives. Never make the user wait for a full exit before anything new appears.
- Keep spatial logic consistent. If a panel entered from the right, it leaves to the right. If going deeper moves content left, going back moves it right.
- Avoid layout jumps: reserve space for content that will load. Animate size changes that would otherwise make surrounding content snap.

## Step 5 - Interruption and state

This is where most generated motion fails, because it is invisible in a single happy-path run.

- Every animation must be interruptible. New input retargets from the current position and velocity. Do not queue it behind the running animation, and do not snap to the end first.
- Never block input for the length of a transition. If a control must not be used yet, show it as disabled.
- Animations are driven by state. Do not sequence them with timers. Timer-chained sequences break when the user acts mid-sequence.
- Rapid repeated triggers must not stack. Ten quick toggles end in the correct final state with no residual animation.
- For optimistic updates, show the result at once, and animate the correction clearly if the operation fails.
- Gestures track the finger one to one while it is down. Resistance at a limit is shown by reduced tracking. Do not use a hard stop.

## Step 6 - Accessibility

- Honor the platform's reduced-motion setting. Replace large movement, scaling, parallax and spring overshoot with a short opacity change or an instant change. Keep the feedback and the state change. Reduced motion does not mean no confirmation.
- Never flash content more than three times in one second. This is a WCAG seizure-safety threshold.
- Anything that moves, blinks or scrolls automatically for more than five seconds alongside other content needs a way to pause or stop it, per WCAG.
- Do not make motion the only carrier of information. A change conveyed by movement must also be visible in the resting state.
- Avoid motion triggered by scrolling that moves content at a different rate across large areas, unless the reduced-motion alternative is implemented.

## Step 7 - Performance

Dropped frames turn good motion into bad motion.

- The total frame budget is about 16.7 ms at 60 Hz and about 8.3 ms at 120 Hz. When total frame work exceeds the budget, visible stutter can result.
- Animate properties that the platform can composite without recomputing layout. On the web that usually means transform and opacity. On native platforms, use the framework's animatable properties and render-thread animations where they exist.
- Do not animate many independent elements when one container can move.
- Measure on the slowest device you intend to support, when tools allow. A desktop preview hides frame drops.

## Verifying motion

Motion cannot be verified by reading code, and only partly by a single screenshot. Use what the environment allows, and report which of these you did.

- Captured frames or a recording at the start, middle and end of the transition.
- Ran the interruption test and the repetition test from the top of this file, by scripted input or by hand.
- Toggled the reduced-motion setting, or emulated it, and observed the alternative.
- Checked a performance trace or frame-timing output.

If you could only read the code, say "motion implemented, not observed running". Do not describe its feel.

## Anti-pattern kill-list

- The same fade-and-rise on every element as the page loads.
- One duration and one curve for everything.
- Linear easing on moving objects.
- Entrance animations that replay on every scroll or re-render.
- Animations that block input until they finish.
- Bounce or overshoot on destructive, error or serious confirmation moments.
- Loading spinners for waits under a few hundred milliseconds. They only add flicker. Delay showing them.
- Skeletons whose shapes do not match the content that replaces them.
- Hover effects as the only feedback on a touch device.
- Motion with no reduced-motion alternative.
- Sequencing by nested timers.

## Default Output vs. Flagship Output

Task: "A list where items can be swiped away to archive, with undo."

Default output:

- On swipe end past a threshold, the item fades out over 300 ms with the default curve, then the list jumps up to fill the gap.
- A toast with "Undo" appears. Undo makes the item pop back in instantly.
- No keyboard path. No reduced-motion handling. A swipe cannot be cancelled once started.

Flagship output:

- The item tracks the finger one to one. An archive affordance is revealed behind it, and changes state when the commit threshold is crossed, so the user knows the outcome before releasing.
- Release below the threshold springs back from the current position and velocity. Release above it continues in the swipe direction at the release velocity. A fast flick commits even over a short distance.
- The gap closes with the same spring, started as the item leaves, so nothing snaps. Other items do not move.
- Undo returns the item along the path it left by, to its original position.
- A keyboard and assistive path exists: a visible archive action on the focused item, and an announced, focusable undo.
- With reduced motion, the item fades over a short duration and the gap closes without travel.
- Verified by: reversing a swipe mid-flight, archiving five items in rapid succession, toggling reduced motion, and capturing frames. Reported which of these were actually run.

## Self-check before reporting

- Can I state the purpose of every animation in one clause?
- Do duration and curve vary with size, distance and direction of travel, using a small set of tokens?
- What happens if the user reverses or repeats the action mid-animation? Did I try it?
- What does a reduced-motion user get, and did I observe it?
- Did I observe the motion running, or only write it?
