# Engineering

Load this for backend, API, data, refactoring, library or SDK use, security-sensitive code, and tests. It is self-contained. It assumes you know the language and frameworks. It covers the passes that separate code that compiles from code that holds up.

## The standard

Flagship engineering means four things, each checkable:

- It uses the APIs that actually exist in the installed versions.
- Its invariants hold under bad input, retries, concurrency and partial failure.
- Its trust boundaries are explicit and enforced on the side that cannot be tampered with.
- It contains no more structure than the current requirements need.

## Pass 1 - API currency

Why: your recollection of an API can be older than the version in the project. Code written from stale memory compiles in your head and fails at runtime, or works while using a deprecated or insecure path.

Do this before using any library, SDK, framework feature or CLI you have not already seen working in this project:

1. Find the installed version from the lockfile, manifest, or the package itself. Do not assume latest.
2. Check one source of truth for that version, in this order of preference: the installed package's own source or type definitions, official documentation for that version, the official changelog or migration guide.
3. If you cannot check any of these, write the code, and put "API usage for X not checked against version Y" in the "not verified" list.

Signals that should trigger a check even for familiar libraries:

- A major version you have not worked with.
- Authentication, payments, cryptography, file upload, or anything from a cloud provider SDK.
- An import path, option name or config key you are reconstructing rather than copying from working code in the repo.
- An error that mentions an unknown argument, a missing export or a deprecation.

Prefer the pattern already used in the repository over the one you remember, unless the repository's pattern is the bug.

## Pass 2 - Invariants and the hard-to-reverse parts

Spend care where mistakes are expensive to undo: the data model, public interfaces, and anything persisted or sent to another party. Everything else is cheap to change.

For each invariant in your frame, decide where it is enforced. The strongest available place wins:

1. Made unrepresentable by the types or schema.
2. Enforced by the datastore: unique constraint, foreign key, check constraint, transaction.
3. Enforced at one choke point in code that every path goes through.
4. Enforced by convention in each caller. This is the weakest and should be rare.

Invariants enforced only at level 4 will be violated by the next caller. If you must use it, say so in the report.

Rules that are invariants in almost every system:

- An operation that can be retried must be safe to retry. Use an idempotency key with a uniqueness guarantee at the datastore, not a read-then-write check, which races.
- State that must change together changes in one transaction, or the partial state is explicitly recoverable.
- Represent money in integer minor units or an exact decimal type, never binary floating point. Represent counts with integer types.
- Persist instants in UTC. Retain an IANA time zone separately when future schedules or local civil-time intent matter; convert for display.
- Every external call has a timeout. A retry has a limit and backoff. Decide what the caller sees when retries run out.

## Pass 3 - Edge cases

Do not list edge cases from imagination. Walk the input and the timeline.

Input walk, for each value that crosses a boundary:

- Empty, missing, null, and wrong type.
- Zero, one, many, and the largest realistic size.
- Boundaries: first and last, exactly at the limit, one past it.
- Hostile shape: very long, deeply nested, duplicate keys, unusual Unicode, leading and trailing whitespace.

Timeline walk, for each operation that changes state:

- The same request arrives twice.
- Two different requests touch the same record at once.
- Events arrive out of order or late.
- The process stops between two writes.
- A dependency is slow, returns an error, or returns success after the caller timed out.

Handle the ones that can happen. Do not write handling for cases the surrounding code makes impossible. For each one you decide not to handle, be able to say why it cannot occur.

## Pass 4 - Security

Run this pass on anything that accepts input from outside the process, handles identity, or touches secrets, money or personal data.

- Authorization is checked on the server for every route and every object, not only at the entry page. Check ownership of the specific record, not only that the user is logged in.
- Untrusted input never reaches an interpreter as code: use parameterized queries, argument arrays for subprocesses, and output encoding for the target context. This covers SQL, shell, HTML, file paths and template engines.
- Secrets come from the environment or a secret store, are never logged, never returned in responses, and never sent to the client.
- Compare secrets and signatures with a constant-time comparison. Verify webhook signatures against the raw request body, before parsing.
- File uploads: limit size, check type by content rather than by name, store outside the web root or in object storage, and never use a user-supplied filename as a path.
- Outbound requests to user-supplied URLs are a server-side request forgery risk. Restrict schemes and block internal address ranges.
- Error messages to the caller say what went wrong for them. Stack traces and internal identifiers stay in logs.
- Rate-limit anything that is expensive, sends messages, or guesses credentials.

If you did not run this pass, the report says so. Do not describe code as secure. Describe which threats you checked.

## Pass 5 - Tests that verify something

Why: a test that restates the implementation passes for wrong code too. The purpose of a test is to fail when behavior is wrong.

For each test, answer: "what specific bug would make this fail?" If there is no answer, delete it or rewrite it.

Priorities, in order:

1. One test per invariant, written to try to break it. For idempotency, send the duplicate. For concurrency, run the operations concurrently, not sequentially.
2. The failure mode you chose in the frame, provoked on purpose.
3. One end-to-end test through the real layers of the thin slice. Use the real datastore or a faithful local equivalent where practical.
4. Edge cases from pass 3 that have real handling.

Guidelines:

- Assert on observable behavior and state, not on which internal functions were called.
- Mock only what you do not own or cannot run: third-party network services, clocks, randomness. A test in which the unit under test is surrounded by mocks tests the mocks.
- When you fix a bug, first write the test that reproduces it and watch it fail. A test you never saw fail is unproven.
- Coverage percentage is not a goal. Ten tests that each catch a distinct bug beat a hundred that assert defaults.

Run the tests. Report the command and the counts. If tests could not be run, say so. Written-but-unexecuted tests go in the "not verified" list.

## Pass 6 - Proportional simplicity

High-bar engineering is the smallest design that meets the invariants. Extra structure is a cost that every later reader pays.

- Add an abstraction when there are at least two real uses that would otherwise diverge, not in anticipation of one.
- Add configuration when a real caller needs a different value, not because a value exists.
- Add a layer when it enforces a boundary that matters: trust, ownership or deployment. Not for symmetry.
- Prefer deleting code to guarding it. Prefer a plain function to a class with one method. Prefer the standard library to a dependency for anything small.
- In a refactor, change behavior or structure, never both in one step. Keep tests green between steps so that a failure points at one change.
- Match the conventions of the codebase you are in, even where you would choose differently. Consistency is worth more than local preference.

Escape hatch: when the user asks for an extensible framework, a plugin system or a library for unknown callers, generality is the requirement. Build it, and keep the public surface as small as the stated use cases allow.

## Observability, proportionally

Add only what someone would need to diagnose the failure modes you named.

- One structured log line at each trust boundary and each external call, carrying a correlation identifier and outcome. No secrets, no personal data.
- Errors carry enough context to act on: which operation, which identifier, which dependency.
- Do not swallow exceptions. Either handle the error meaningfully, or let it propagate to a place that does.

## Default Output vs. Flagship Output

Task: "Add an endpoint that lets a user update their shipping address on an order."

Default output:

- A route that loads the order by ID and writes the new address.
- Validates that fields are non-empty.
- A test that posts an address and expects status 200.

Flagship output:

- Checks that the order belongs to the authenticated user, on the server. Returns "not found" rather than "forbidden", so order IDs cannot be probed.
- States the invariant "an address cannot change after the order has shipped", and enforces it in the same conditional update statement that writes the address, so that a concurrent "mark shipped" cannot slip between check and write.
- Validates length and character limits at the boundary, once.
- Tests: another user's order is refused. A shipped order is refused. A concurrent ship and update never produce a shipped order with a changed address.
- Reports that the tests ran and their counts, and that address validity against a postal service was not checked.

The second version adds no abstractions. It adds one ownership check, one conditional write and three tests that could each fail.

## Self-check before reporting

- For each new library call: did I check it against the installed version, or list it as unchecked?
- For each invariant: where is it enforced, and what test tries to break it?
- Did I provoke at least one failure, rather than only running the happy path?
- Is there any untrusted input that reaches a query, shell, path or template without parameterization or encoding?
- Is there anything here that exists only for a future requirement nobody stated?
- Did I run the tests after my last edit?
