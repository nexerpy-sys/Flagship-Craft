# Design

Load this for any user-facing visual surface: page, screen, component, dashboard, document layout or data visualization. It is self-contained. It teaches a method for reaching a product-specific design. It does not prescribe a style. Any aesthetic the user names is correct. Where the target is not the web, apply the same method with that platform's own conventions and units.

## The standard

A flagship design can be explained. For every visible decision, you can say what it does for this user doing this task. A template design cannot be explained, only described.

Two tests, both observable:

- Swap test: replace the product name and copy with those of an unrelated product. If the design still fits equally well, it was not designed for this product.
- Squint test: blur or shrink the rendered screen until text is unreadable. The most important thing should still be the most prominent thing, and the groups should still be visible as groups.

## Step 1 - Concept before components

Write this before choosing any layout or component. Five lines is enough.

1. Who is using this, and in what situation? Include the physical context when it matters: device, distance, light, hands, time pressure.
2. What is the one thing they need to see or do first?
3. What should the product feel like to that person, in two or three plain words, and what is one thing it must not feel like?
4. Which two or three design decisions follow from the answers above? These are the signature decisions. Everything else supports them.
5. What is deliberately absent?

A concept is specific when it rules things out. "Clean and modern" rules out nothing. "A tool read at arm's length in sunlight by someone wearing gloves, so: very high contrast, few large targets, no hover-dependent controls, status readable in one glance" rules out most default layouts.

If the user supplied a brand, a reference or an existing interface, the concept starts from it. Extend the existing system. Do not replace it.

## Step 2 - Decide the system, then assemble

Make these decisions once, as named values, before building screens. Then use only these values.

Type:

- Choose at most two families. One is often enough. Pick them for the content: long reading, dense data and short display text need different things.
- Define a small scale of sizes, usually four to six steps. Adjacent steps should be visibly different at a glance. If two steps are hard to tell apart in the rendered output, merge them.
- Body text line length around 45 to 75 characters is a widely used readability range for running text. Dense data views and short labels are exceptions.
- Hierarchy comes from size, weight, color and space. Use the fewest of these that make the levels distinct.

Space:

- Choose one base unit and build spacing from a short list of its multiples. Use the list everywhere.
- Space expresses grouping. The distance within a group must be visibly smaller than the distance between groups. This is the most common coherence failure, and it is checkable in a screenshot.
- Density is a product decision. An expert tool used all day can be dense. A first-run screen cannot. Choose it from the concept. Do not default to airy.

Color:

- Assign roles, not swatches: background, surface, primary text, secondary text, border, one primary action color, and status colors for success, warning and danger.
- One accent that means "this is the action or the selected thing". If the accent appears on decoration too, it stops carrying meaning.
- Never use color as the only carrier of meaning. Pair it with text, an icon or shape.
- Contrast minimums from WCAG 2.x AA: 4.5 to 1 for normal text, 3 to 1 for large text and for the visual boundaries of interactive components. Measure these. Do not estimate them.

Shape and depth:

- One corner-radius family, one border treatment, one elevation model. Decide whether layers are separated by shadow, by border or by tone, and use that one method consistently.

Interaction:

- Every interactive element has distinct, visible states: default, hover where a pointer exists, focus, pressed, disabled, loading. Keyboard focus must always be visible.
- Target sizes: about 44 by 44 points on iOS and 48 by 48 density-independent pixels on Android, per the platform guidelines. WCAG 2.2 AA sets a floor of 24 by 24 CSS pixels on the web. Larger is better for primary actions.
- Design the empty, loading, error and overflow states as part of the screen, not afterwards. An interface is judged most in the states the demo did not show.

Escape hatch: when extending an existing product, its tokens are the system. Use them even where you would choose differently, and flag real problems separately.

## Step 3 - Compose

- Decide the reading order first, then the layout that produces it. One primary focal point per view.
- Let content determine structure. Three unequal things should not be forced into three equal cards.
- Alignment: every element should share an edge or axis with something else. Count the distinct left edges in a screenshot. Fewer is calmer.
- Use real, representative content: realistic lengths, a long name, a large number, a missing image. Placeholder text hides layout failures.
- Proportion is judged, not computed. Ask whether the size of each element matches its importance to the task. Do not apply a ratio by rule.

## Anti-pattern kill-list

Each of these is observable in a screenshot. Remove them unless the concept specifically calls for one, and say why if it does.

- A centered headline, sub-headline and two buttons over a gradient, followed by three equal feature cards with icons.
- Purple-to-blue or violet gradients used as the default way to look current.
- Every section built from the same card, with the same radius, shadow and padding.
- Decorative icons or emoji standing in for content hierarchy.
- Glass blur, glow or gradient text applied with no relation to the product.
- Uniform spacing everywhere, so that nothing is grouped.
- A dashboard of equal-weight stat tiles in which no number matters more than another.
- More than one accent color competing for "primary".
- Grey text on a tinted background that fails contrast.
- Hover-only affordances on a touch surface.
- Invented testimonials, logos or metrics. Use clearly labelled sample content instead.
- A dark theme made by inverting a light one, without rebalancing contrast and elevation.

The opposite failure is also on the list: arbitrary novelty. Unusual layout, type or color that the concept cannot justify is noise.

## Step 4 - Critique loop on rendered output

Source code does not show overlap, clipping, weak hierarchy or broken wrapping. Whenever any rendering or screenshot tool is available, run this loop. If none is available, say so in the report, and list design as not visually verified.

1. Render the real thing with realistic content.
2. Capture it at the sizes that matter for this product. For responsive web: a narrow phone width around 360 to 390 CSS pixels, a tablet or small laptop width, and a wide desktop width. For fixed-size or native targets: the smallest and largest supported sizes.
3. Inspect each capture against the questions below.
4. Name the single weakest visual decision. Fix it. Capture again.
5. Repeat until a pass finds nothing you would be embarrassed to defend. Usually that is two or three rounds.

Critique questions, answered from the capture, not from memory of the code:

- Hierarchy: in the squint test, what is most prominent? Is that the thing the concept said comes first?
- Grouping: are related things visibly closer to each other than to unrelated things?
- Coherence: how many distinct font sizes, spacing values, radii and colors can you count? Is each one doing a job?
- Typography: is any line too long to read comfortably, or any label truncated or wrapping badly? Is there a heading orphaned from its content?
- Contrast: does every text and control meet the minimums? Check the lightest text on its actual background.
- Responsiveness: is anything clipped, overlapping or horizontally scrolling at the narrow size? Does the wide size merely stretch, or does it use the space?
- States: have you seen the empty, loading, error and long-content states rendered, not just imagined them?
- Concept: does the screen pass the swap test? Which signature decision is visible?
- Restraint: what could be removed with no loss to the user?

Record what you looked at. "Inspected captures at 375, 768 and 1440 wide. Fixed the heading wrap at 375 and low-contrast secondary text" is evidence. "The design is polished" is not.

## Accessibility floor

These are not style choices, and they apply to every concept.

- Text and controls meet the contrast minimums above.
- Everything operable by pointer is operable by keyboard or the platform's assistive input, with visible focus and a logical order.
- Interactive elements have accessible names. Images that carry meaning have text alternatives.
- Text can be enlarged to 200 percent without loss of content or function on the web, and respects the system text-size setting on native platforms.
- Nothing depends on color alone, on hover alone or on motion alone.

## Default Output vs. Flagship Output

Brief: "A dashboard for a small bakery owner to see how today is going."

Default output:

- A sidebar with eight navigation items, a header with search and an avatar.
- Four equal stat cards: revenue, orders, customers, average order.
- A line chart of revenue over 30 days and a table of recent orders.
- Looks like every admin template. Passes no swap test.

Flagship output:

- Concept: the owner checks this on a phone between tasks, hands possibly floured, wanting one answer - "am I on track today, and what needs me now?" It should feel like a note from a trusted shift lead. It must not feel like analytics software.
- Signature decisions: one large plain-language status line at the top ("Ahead of a normal Tuesday by 12 percent"). Below it, a short list of things needing action now (two items running low, one pickup overdue). Everything else is secondary and collapsed.
- System: one type family, four sizes, one accent used only for items needing action. Large targets. No navigation chrome on the phone layout.
- Checked: captures at phone and desktop widths. Fixed a status line that wrapped to three lines on the narrow size. Measured contrast on the secondary text.

The second version has fewer elements. It is better because each one can be explained.

## Self-check before reporting

- Can I state the concept in two sentences, and does it rule anything out?
- Can I point to the signature decisions in the rendered output?
- Did I look at real captures at the relevant sizes, and what did I change because of them?
- Does anything from the kill-list remain without a reason?
- Did I measure contrast and target size, rather than assuming them?
- Which states did I render, and which did I only describe?
