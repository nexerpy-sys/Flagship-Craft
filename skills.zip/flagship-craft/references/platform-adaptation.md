# Platform Adaptation

Load this when the target is native desktop, mobile, terminal, game engine, embedded display, or more than one platform. It is self-contained. It is not a generic backend module; use `engineering.md` for non-visual backend and API work.

Purpose: keep the principles, change the form. The common failure is carrying web habits (CSS thinking, hover states, page scrolling, card grids) onto platforms where users expect something else.

## The rule

On every platform, ask the same questions:

- What does this platform's user already expect, from the operating system and from the best software on it?
- What are this platform's input methods, and which one is primary?
- What are its real constraints: screen, power, memory, connectivity, latency, distribution?
- What is its own system for layout, type, color and animation?

Then express the principle in that system. When the platform has a strong convention, follow it unless the product has a stated reason to differ. Platform conventions are knowledge the user already has, and each departure costs them effort.

## Translation table

| Principle | Web | Mobile native | Desktop native | Terminal | Game or interactive visual | Backend or API |
| --- | --- | --- | --- | --- | --- | --- |
| First thing the user needs | Above the fold at narrow width | Reachable by thumb, primary action low on screen | Visible in the main window without opening menus | First line of output. Most important line last when output scrolls | Readable during play without looking away from the action | The common call is the shortest, with the safest defaults |
| Hierarchy | Size, weight, space | System text styles and dynamic type | Window regions: sidebar, content, inspector. Toolbars | Order, indentation, sparing emphasis | Size, contrast against the scene, motion, sound | Naming, and which fields are required or optional |
| Feedback to input | Visible state change within about 100 ms | The same, plus haptics where conventional | Cursor change, selection, focus ring, menu state | Immediate echo. Progress for anything over about a second | Game feel: response on the same or next frame | Fast, specific errors. Explicit acknowledgement for async work |
| States | Empty, loading, error, offline | The same, plus permission denied, backgrounded, interrupted by a call | The same, plus multi-window, unsaved changes | Not a TTY, no color, narrow width, piped output | Paused, focus lost, controller disconnected | Timeout, partial failure, retry, rate limited |
| Accessibility | Keyboard, focus, contrast, accessible names | Screen reader labels, dynamic type, target size | Full keyboard access, screen reader roles, high-contrast mode | Works without color. Readable by a screen reader. No reliance on cursor tricks | Remappable input, subtitles, color-independent cues, difficulty and motion options | Clear error text, stable machine-readable codes |
| Motion | Composited properties, reduced-motion media query | Platform springs and transitions, system reduce-motion setting | Restrained. Window and sheet behaviors come from the system | Almost none. Spinners and progress only, and none when piped | Central to feel. Budgeted per frame | Not applicable |

## Mobile native

- Use the platform's navigation model: its own back behavior, tab or navigation bars, sheets and gestures. Do not rebuild web navigation.
- Respect safe areas, the on-screen keyboard, orientation, and system text size. Test the largest text size, because it breaks fixed layouts.
- Targets are about 44 by 44 points on iOS and 48 by 48 density-independent pixels on Android, per the platform guidelines.
- No hover. Every hover-revealed control needs a visible or long-press alternative.
- Design for interruption. The app can be backgrounded or killed at any moment. State that matters is saved before that, not on exit.
- Assume intermittent connectivity. Decide what works offline, what is queued, and how the user sees pending and failed sync.
- Request permissions at the moment of need, with the reason visible. Handle refusal as a normal state.
- Use platform springs and interruptible, gesture-driven transitions. Interfaces that cannot be interrupted feel foreign on touch devices.

## Desktop native

- The keyboard is a primary input. Common actions have shortcuts that follow the platform's standard. Every action is reachable from a menu or command surface. Focus order is deliberate.
- Follow the operating system's conventions for menus, window controls, dialogs, settings and file handling. They differ between macOS, Windows and Linux desktops. Do not ship one platform's conventions to all three.
- Windows resize continuously, and there may be several. Design the minimum size, and decide what each region does when there is extra space.
- Density can be higher than on the web. Pointer precision is high, and sessions are long.
- Support selection, multi-selection, drag and drop, undo and redo, and context menus where users would expect them.
- Motion is restrained and brief. Long transitions on a tool used for hours become a tax.

## Terminal and command-line tools

- Detect whether output is an interactive terminal. When it is piped or redirected, emit plain, stable, parseable output with no color, no cursor movement and no spinners.
- Honor the `NO_COLOR` convention and the terminal's width. Never rely on color alone.
- Results go to standard output. Diagnostics and progress go to standard error. Exit code zero means success. Non-zero codes are documented and consistent.
- Offer a machine-readable output mode for anything a script might consume.
- Handle interrupt signals: stop promptly, leave no partial or corrupt state, and restore the terminal.
- Error messages say what failed, why, and what to do next. Destructive actions require confirmation or an explicit flag, and offer a dry run.
- Paths, line endings, encodings, shells and file permissions differ across operating systems. Use the language's path and filesystem libraries, not string handling.

## Games and interactive visuals

- Feel is the product. Input-to-response latency and frame pacing matter more than any single visual.
- Separate simulation from rendering. Advance the simulation on a fixed timestep, or scale by elapsed time, so behavior does not change with frame rate.
- Set a frame budget for the weakest target device, and measure against it.
- Readability under motion: the player must be able to tell at a glance what is interactive, what is dangerous, and what just happened. Use redundant cues: shape, motion and sound, not color alone.
- Effects such as screen shake, flashes and camera motion get an intensity option or an off switch. Never flash more than three times in a second.
- Handle pause, loss of focus, resize and device loss. On the web, handle a lost graphics context.
- Juice supports clarity. If an effect hides state the player needs, remove it.

## Backend, APIs and non-visual systems

There is no visual surface here, so the design and motion references do not apply. The same care is expressed as interface design.

- The interface is the product. Names, shapes, defaults and errors are its usability. Make the common call short and safe. Make the dangerous call explicit.
- Be consistent in naming, pagination, time formats, identifiers and error structure across the whole surface.
- Errors are specific and actionable for the caller, with stable machine-readable codes and no leaked internals.
- Feedback and status translate to idempotency, explicit acknowledgement of async work, a queryable job state, and observable health.
- Decide the versioning and compatibility policy before the first external caller exists.

## Multi-platform work

- Share the product concept, the content hierarchy, the data model and the logic. Do not share pixel-identical layouts.
- Write down, per platform, the primary input, the navigation model and the conventions you are following. Three lines per platform is enough.
- Cross-platform frameworks give one codebase. They do not give one design. Budget for per-platform adjustment of navigation, typography, spacing, motion and system integration.
- Decide explicitly what is identical everywhere (brand, vocabulary, core flows) and what adapts (navigation, controls, density, motion, shortcuts).

## Verification on platforms you cannot run

This is a common situation, and it has an honest answer.

- State exactly which platforms and devices you ran on. Everything else is "not verified".
- A simulator or emulator run is evidence for layout and logic. It is not evidence for performance, haptics, real gesture feel or sensor behavior. Label it as a simulator run.
- Code written for an operating system you did not execute on is unverified on that system, however portable it looks. Name the specific risks: path handling, permissions, signals, line endings, fonts.
- Where possible, give the user the shortest command or step list that would verify it on their device.

## Default Output vs. Flagship Output

Task: "Port our web settings page to the iOS and Android apps."

Default output:

- The same stacked cards and toggles as the web page, scaled down, with a floating save button and a custom back arrow.
- Identical on both platforms.
- Described as done after a web preview.

Flagship output:

- Uses each platform's own grouped-list settings pattern, its own switches, and its own back navigation.
- Removes the save button on platforms where settings apply immediately by convention. Shows inline confirmation, and handles a failed save by reverting the control with a visible reason.
- Handles the largest system text size, a notification-permission row that reflects the real system permission state, and offline changes that queue.
- States that layout was checked in one iOS simulator and one Android emulator, and that real-device behavior and screen-reader behavior were not verified.

## Self-check before reporting

- Did I name the primary input and navigation model for each target platform?
- Is there any web-only pattern here (hover dependence, page scroll assumptions, card grids, custom navigation) on a platform that has its own convention?
- Which platform-specific states did I handle: backgrounding, piping, resize, focus loss, permission refusal?
- Which platforms did I actually run on, and is everything else listed as not verified?
