# Framing and Decisions

Load this when the brief is ambiguous, when several architectures are plausible, or when a wrong early choice would be expensive. It is self-contained.

Purpose: stop the jump from a vague brief straight to implementation. The goal is not a longer plan. The goal is to find the few facts that would change what you build, before you build it.

## The core move

Before implementation, produce a frame that a reviewer could disagree with. A frame nobody could disagree with ("build a reliable, scalable system") contains no decisions.

A usable frame has six parts. Write one to three lines for each.

1. Outcome. What a named kind of user can do afterwards. Not a feature list.
2. Hidden requirements. What the brief did not say but would be considered broken if missing.
3. Constraints. What you cannot change: platform, existing data, conventions, budgets, deadlines stated by the user.
4. Invariants. Statements that must hold for all inputs and all orderings of events.
5. Failure modes. How this breaks in real use, ranked by likelihood times cost.
6. Decision and reversibility. What you will build, the main alternative you rejected, and what it would cost to switch later.

## Finding hidden requirements

Do not brainstorm freely. Walk these seven probes and write down only the ones that produce something.

- States: what does this look like when empty, loading, partially loaded, failed, offline, and with far more data than expected?
- Actors: who else touches this? Other users, other roles, other services, scheduled jobs, the same user on a second device.
- Time: what happens on retry, on double submission, when events arrive out of order, when a process dies halfway, when clocks disagree?
- Existing reality: what data, users or callers already exist that the new behavior must not break?
- Boundaries: where does untrusted input enter? Where do secrets, personal data or money cross a boundary?
- Limits: what are the largest realistic size, rate and duration? What happens just past them?
- Exit: how is this undone, migrated away from, or turned off?

Stop when two probes in a row produce nothing new. For a bounded task, that usually takes under a minute of thought.

## Writing invariants

An invariant is useful only if it is testable and could plausibly be violated.

| Weak | Usable |
| --- | --- |
| "Data should be consistent" | "The sum of ledger entries for an account equals its stored balance after every committed transaction" |
| "Handle duplicates" | "Processing the same event ID any number of times produces the same state as processing it once" |
| "The UI should be responsive" | "No content is clipped or horizontally scrollable between 320 and 1920 CSS pixels wide" |
| "Secure access" | "A request can read a record only if the authenticated user owns it, checked on the server for every route" |

Aim for two to five invariants. Each one becomes a check later, or an explicit entry in the "not verified" list.

## Decide or ask

Asking has a cost: it stalls the work and pushes thinking onto the user. Guessing has a cost: rework. Use reversibility to choose.

- Decide silently: naming, formatting, file layout, equivalent library choices, defaults the user can change in one line.
- Decide and state the assumption: anything a reasonable user might have wanted differently but that is cheap to change. Put it in the final report.
- Ask before acting: destructive or irreversible actions, spending money, changing approved scope, choices that fix the data model or public interface, and anything touching real credentials or production data.

When you ask, ask once, give two or three concrete options, mark your recommended default, and say what you will do if there is no answer. If the user has said not to ask, treat every question as "decide and state the assumption", and choose the option that is easiest to reverse.

## Choosing between approaches

When more than one architecture is plausible, compare at most three, and compare them on the same axes. Long option menus are a way of avoiding the decision.

1. State the simplest approach that could meet the invariants. This is the default.
2. State the strongest alternative and the specific condition under which it would win. Example: "CRDTs win if users must edit the same paragraph offline. Otherwise per-block last-write-wins with presence is enough."
3. Check whether that condition holds in the brief. If it does not, and you cannot find out cheaply, choose the default and record the condition as a trigger to revisit.
4. Name what is hard to reverse in your choice, usually the data model and public interfaces, and spend your care there. Everything else can be changed later.

Evidence beats argument. If a doubt can be settled by a ten-minute spike, a benchmark, or reading the docs, do that instead of reasoning about it.

## Proportional depth

Match the frame to the stakes.

| Situation | Frame size |
| --- | --- |
| Bounded change in familiar code | 3 to 5 lines, in your head or in the response |
| New feature across layers | 8 to 12 lines |
| Architecture or data-model decision | Up to one page: frame, two or three options on shared axes, decision, revisit triggers |

Signs you have over-framed: the frame restates the brief, lists risks you will not act on, or contains options nobody would choose. Signs you have under-framed: you discover a requirement while testing that one of the seven probes would have found.

## Default Output vs. Flagship Output

Brief: "Add CSV export to the reports page."

Default output:

- Adds an export button that serializes the current table rows in the browser.
- Works on the 20 rows in the demo data.

Flagship output:

- Notices the table is paginated, so "export" most likely means all matching rows, not the visible page. States this assumption.
- Notices cell values starting with `=`, `+`, `-` or `@` can be interpreted as formulas by spreadsheet software, and neutralizes them.
- Notices that the export must apply the same permission filter as the page, on the server.
- Picks streaming on the server because row count is unbounded, and says that a client-side export would be simpler if the report were capped.
- Tests a field containing a comma, a quote and a newline, and reports which checks were run.

The second version is not longer because of ceremony. It is longer because four real requirements were found before code was written.

## Self-check before leaving the frame

Answer these. If any answer is "no", fix the frame, not the code.

- Could a reviewer disagree with something in this frame?
- Does each invariant name something that could actually be violated?
- Did I name the alternative I rejected and the condition that would reverse the choice?
- Is every question I am about to ask one whose answer changes what I build?
- Is the frame shorter than the work it governs deserves, and no longer?
