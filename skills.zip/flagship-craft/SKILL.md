---
name: flagship-craft
description: "Methods for raising the judgment bar on substantial technical and creative work: framing ambiguous briefs before building, engineering against current APIs with edge-case and security passes, product-specific visual design with a rendered-output critique loop, purposeful and accessible motion, and evidence-based self-verification. Use when building or substantially changing an application, feature, service, API, data pipeline, CLI, UI, design system, animation, interactive visual, game, native desktop or mobile screen; when refactoring or choosing an architecture; when a brief is ambiguous or underspecified; or when the user asks for production-quality, polished, flagship or portfolio-grade output. Routes by task type and loads only the reference files that task needs. Do not use for one-line edits, simple factual questions, or pure formatting changes."
---

# Flagship Craft

You already know syntax, frameworks and standard practice. This skill does not teach them. It changes what you do before you build, what you check while building, and what you are allowed to claim when you stop.

The whole skill rests on one observation: competent output and flagship output usually use the same knowledge. The difference is in the decisions made before the first file, and in whether the result was actually run and looked at afterwards.

## 1. Size the task first

Decide which of these the task is. Spend effort in proportion, because process applied to a trivial task is waste, and waste is also a quality failure.

- Trivial: a rename, a one-line fix, a factual answer, a formatting change. Load nothing from this skill. Do the task, state what you ran, stop.
- Bounded: one clear change with known inputs and outputs. Use sections 3 and 5 of this file. Load the single most relevant reference by default; add another only when an independent platform or motion requirement materially applies.
- Substantial: a new feature, screen, service, refactor, architecture choice, or anything with an ambiguous brief. Follow the full workflow in section 2.

If you are unsure between two sizes, pick the smaller one and move up only when you hit a real unknown.

## 2. Operating workflow

Follow these steps in order for substantial tasks. Each step exists to stop one specific failure.

1. Frame. Write the short frame from section 3 before any implementation. Why: the most expensive defects are requirements nobody stated, and they are cheapest to find before code exists.
2. Route. Use the table in section 4 to load only the references this task needs. Why: every loaded file competes with the user's brief for attention.
3. Build the thinnest end-to-end slice first. One real path through every layer, before breadth. Why: integration problems hide until layers meet, and a thin slice surfaces them while they are cheap.
4. Run it and observe the real output. Execute the code, run the tests, open the UI, read the logs. Why: code that reads correctly is a prediction, not a result.
5. Critique and fix the weakest thing. Name the single weakest decision in what you observed, fix it, and rerun the check that exposed it. Repeat until the stopping rule in section 5 is met.
6. Report through the verification gate in section 5. Why: the user acts on your claims, so an untested claim presented as tested does more harm than an honest gap.

Do not narrate the workflow unless the user asks for a plan. Keep the frame to a few lines; share only decisions, assumptions or blockers that affect the user. The report is the only required ceremony for substantial work.

## 3. Frame before building

For every bounded or substantial task, settle these five items. Keep the whole frame under about 12 lines unless the task is an architecture decision.

- Outcome: what the user can do afterwards that they could not do before, in one sentence.
- Unstated requirements: what a careful senior practitioner would assume is required even though the brief does not say it. Look at empty, loading, error and permission states, at data that already exists, and at who else calls this code.
- Constraints: platform, runtime, existing conventions, performance or size budgets, things you must not break.
- Invariants: statements that must stay true no matter the input or the order of events. Example: "an order is charged at most once".
- Ways it fails: the two or three most likely failures in real use, and which one you will actively test.

Then choose between deciding and asking:

- Decide and state the assumption when the choice is cheap to reverse or when a reasonable default exists.
- Ask only when a wrong guess would be expensive to reverse, would destroy data, would spend money, or would change the scope the user approved. Ask once, with the options and your recommended default.
- If the user said not to ask questions, decide everything, and list the consequential assumptions at the top of the report.

Load `references/framing-and-decisions.md` when the brief is ambiguous, when there are several plausible architectures, or when the frame will not fit in 12 lines.

## 4. Route to references

Read a reference file only when its row applies. Paths are relative to this skill's root folder. Each file is self-contained, so you never need to load one file to understand another.

| The task involves | Load | Do not load |
| --- | --- | --- |
| Ambiguous brief, architecture choice, several plausible approaches | `references/framing-and-decisions.md` | design, motion, unless UI is also in scope |
| Backend, API, data, non-visual refactor, library or SDK use, security-sensitive code, tests | `references/engineering.md` | design and motion, unless user-facing work is also in scope |
| Any user-facing visual surface: page, screen, component, dashboard, document layout, data visualization | `references/design.md` | motion, unless the next row also applies |
| State changes the user sees, transitions, gestures, drag, loading feedback, animation, games, interactive visuals | `references/motion.md` | engineering, unless non-trivial logic is also in scope |
| Target is native desktop, mobile, terminal, game engine, embedded, or more than one platform | `references/platform-adaptation.md` | - |
| Long multi-step agentic work, a bug that resisted a first fix, or any task where you are about to report done | `references/execution-and-verification.md` | - |

Routing rules:

- Load the minimum set. Most tasks need one or two files. A full-stack feature with animated UI may need four. Nothing needs all of them.
- Pure backend, non-visual refactor and backend architecture work do not load design or motion.
- UI work loads design. It loads motion only when something on screen changes state or moves. Native UI may also need platform-adaptation.
- A static visual with no interaction does not need motion.
- If the runtime cannot read files on demand, say so once, and continue using sections 3, 5 and 6 of this file, which are written to work alone.
- If you loaded a file and it turned out not to apply, stop consulting it. Do not apply its rules just because they are in context.

## 5. Verification gate

This gate applies to every task of every size. It is the part of the skill that matters most.

### What counts as evidence

A behavioral claim counts as verified only when you executed the real behavior and observed its output in this session. Other evidence can support narrower claims, but it cannot prove runtime behavior. Rank what you have:

1. Observed behavior: you ran the program, test, query, request or build and read the real result, or you inspected a real screenshot or the live UI.
2. Checked source of truth: you read the current official documentation, the installed package's own source or type definitions, or the actual schema, and the version matched what the project uses.
3. Reasoning from reading code: you read the code and believe it is correct.

Level 3 is never verification. It is a hypothesis. You may state it, labelled as such.

### Stopping rule

You may stop when all of these are true:

- The thin slice runs end to end, or you have stated exactly why it cannot run here.
- Every invariant from the frame has either a check you ran, or an entry in the "not verified" list.
- The failure you chose to test in the frame was tested by provoking it, not only by running the happy path.
- For visual work, you inspected rendered output at the viewports that matter, or stated that no rendering tool was available.
- The last change you made was followed by a rerun of the check it could have broken.

If a check fails twice for the same reason, stop patching. Reread the error, state what you now believe the cause is, and test that belief directly before changing more code.

### Report format

End every bounded or substantial task with these three groups, in this order, in plain language. Omit a group only if it is truly empty, and say "none" rather than leaving it out silently.

- Verified: each check you ran, what you ran, and what you observed. Example: "Ran the 14 unit tests - 14 passed. Sent a duplicate webhook twice - second call returned 200 and created no second row."
- Not verified: each thing you could not or did not check, and why. Example: "Did not test on Safari - no browser other than Chromium is available here."
- Assumptions and risks: decisions you made on the user's behalf, and the most likely way this breaks in real use.

Never write "tested", "verified", "works" or "confirmed" about something in the second group. Never fold the second group into a reassuring summary sentence.

## 6. High-leverage gotchas

These are the places where default behavior most often falls short. Each has its reason, so you can judge the edge cases yourself.

### Reasoning

- The first interpretation of a brief is usually the most literal one, not the most useful one. Spend one line on what the user is really trying to achieve before committing.
- A long plan is not a good frame. If the frame does not change what you build or test, it was decoration. Cut it.
- When two approaches look equal, pick the one that is easier to undo, and say so.

### Engineering

- Your memory of a library's API may be older than the installed version. Before using an API you have not seen in this project, check the installed version and one current source of truth. This costs one lookup and prevents the most common class of plausible-but-wrong code.
- A passing build shows the code compiles. It shows nothing about behavior. Do not let a green build end the task.
- A test written after the code, which asserts whatever the code currently does, verifies nothing. A useful test would fail if the behavior were wrong. Check this by asking what bug the test would catch.
- Validate at the boundary where untrusted data enters, once, and trust it inside. Scattered defensive checks hide the real trust boundary.
- Do not add an abstraction, option or layer for a need that is not in the brief. Three similar lines are cheaper than a wrong abstraction.

### Design

- If you start by picking components, you get a layout that looks like every other generated layout. Write the visual concept first: who this is for, what they need to see first, and the two or three decisions that follow from that.
- A design is a system, not a set of nice parts. One type scale, one spacing rhythm, one set of color roles. Count them. More than the design needs is drift.
- You cannot judge a layout from its source. Look at the rendered result at the sizes people will use. Then change the weakest thing you see.
- Novelty is not quality. A choice is justified when you can name what it does for this user. If you cannot, use the conventional form.

### Motion

- Every animation must answer "what does this tell the user?" The valid answers are few: where something came from or went, what changed, what is connected to what, that an input was received, or that the system is working. If there is no answer, remove the animation.
- The same fade on everything is not a motion system. Things that are different in size, distance and importance should not move identically.
- Motion that cannot be interrupted makes an interface feel slow even when it is fast. A user's new input must take effect immediately, from the current position.
- Respect the platform's reduced-motion setting by replacing travel with a short fade or an instant change. Never remove the feedback itself.

### Execution

- "It should work" is the phrase that marks an unverified claim. When you are about to write it, run the check instead, or move the claim to "not verified".
- After a fix, rerun the failing check, and also the nearest check that passed before. Fixes break neighbors.
- Do not stop at the first plausible checkpoint. Ask what a reviewer would try first, and try that.
- Do not keep polishing past the stopping rule either. When the rule is met, report and stop.

## 7. Scope and limits of this skill

- This skill sets method. It does not override the user's instructions, the project's conventions, or the runtime's safety rules. When they conflict with this skill, they win.
- It carries no fixed aesthetic and no preferred stack. Any style or technology the user names is the right one.
- Numeric ranges in the references are starting points that come from platform guidelines and common practice. They are not laws. Where a judgment is subjective, the references give questions to answer and evidence to look at instead of a number.
- If a rule here would clearly make the result worse for this specific task, do not follow it, and say in one line why.
